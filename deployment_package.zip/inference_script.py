import joblib
import pandas as pd
import numpy as np
import os
import json

# --- Configuración de Archivos ---
MODEL_FILE = 'modelo_xgb.joblib'
# El archivo que contiene el orden y nombre exacto de las 530 columnas
FEATURE_NAMES_FILE = 'variables_candidatas.json' 
MODEL_PATH = os.path.join(os.getcwd(), MODEL_FILE)
FEATURES_PATH = os.path.join(os.getcwd(), FEATURE_NAMES_FILE)

# Variable global para almacenar el orden de las columnas entrenadas
GLOBAL_FEATURE_NAMES = None 

# --- 1. Función para cargar el modelo (se ejecuta una vez) ---
def model_fn(model_dir=None):
    """Carga el modelo serializado en memoria y las columnas esperadas."""
    global GLOBAL_FEATURE_NAMES
    
    if not os.path.exists(MODEL_PATH) or not os.path.exists(FEATURES_PATH):
        raise FileNotFoundError("Archivos esenciales (modelo o lista de columnas) no encontrados.")
    
    print(f"Cargando modelo desde: {MODEL_PATH}")
    model = joblib.load(MODEL_PATH)
    
    # Cargar la lista de 530 nombres de columnas para asegurar el orden en la predicción
    with open(FEATURES_PATH, 'r') as f:
        GLOBAL_FEATURE_NAMES = json.load(f)
        
    print(f"Modelo y {len(GLOBAL_FEATURE_NAMES)} nombres de características cargados exitosamente.")
    return model

# --- 2. Función para preprocesar los datos (antes de la predicción) ---
def input_fn(request_body, content_type='application/json'):
    """Deserializa el JSON de entrada y asegura que tenga la estructura y orden correctos."""
    global GLOBAL_FEATURE_NAMES
    
    if content_type == 'application/json':
        data_dict = json.loads(request_body)
        
        # 1. Crear DataFrame a partir del JSON de entrada (ej: {'V10A': 1, 'CP_PesoMadre': 65, ...})
        try:
            df_input = pd.DataFrame([data_dict])
        except Exception as e:
            raise ValueError(f"Error al crear DataFrame desde JSON: {e}")
        
        # 2. **PASO CRÍTICO:** Asegurar que el DataFrame tiene las 530 columnas en el ORDEN exacto
        # Si una columna categórica (como 'CSP_TipoVivienda_2') no está en el JSON, 
        # reindex la añade con fill_value=0, que es la imputación más común para one-hot encoding.
        
        if GLOBAL_FEATURE_NAMES is None:
             raise RuntimeError("Lista de características no cargada. Revisar model_fn.")
             
        df_final = df_input.reindex(columns=GLOBAL_FEATURE_NAMES, fill_value=0)
        
        # NOTA: Si usaste imputación avanzada (ej: Media), esa lógica debe aplicarse aquí después del reindex.

        return df_final
    raise ValueError(f"Tipo de contenido no soportado: {content_type}")

# --- 3. Función para realizar la predicción ---
def predict_fn(input_data, model):
    """Realiza la predicción usando el modelo cargado."""
    # El input_data (df_final) ya está garantizado a tener 530 columnas en el orden correcto
    prediction = model.predict(input_data)
    probabilities = model.predict_proba(input_data)[:, 1]
    
    result = {
        'prediction_label': int(prediction[0]),
        'probability_risk': float(probabilities[0])
    }
    return result

# --- 4. Función para formatear la salida (opcional) ---
def output_fn(prediction, accept='application/json'):
    """Serializa la predicción de vuelta a JSON."""
    if accept == 'application/json':
        return json.dumps(prediction), accept
    raise ValueError(f"Tipo de retorno no soportado: {accept}")

print("Archivo inference_script.py creado.")
